
INSERT INTO "flighttype" VALUES ('D','direct'),
	('O','outbound'),
	('R','return');
