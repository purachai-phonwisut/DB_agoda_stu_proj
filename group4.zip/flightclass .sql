
INSERT INTO "flightclass" VALUES ('Eco','Economy class'),
	('Biz','Business class'),
	('Pre','Premium economy class'),
	('Fir','First class');
