
INSERT INTO "airline" VALUES ('TG','Thai Airways'),
	('PG','Bangkok Airways'),
	('WE','Thai Smile'),
	('FD','Thai AirAsia'),
	('VZ','Thai VietJet Air'),
	('DD','Nok Air'),
	('SL','Thai Lion Air'),
	('8J','Asia Atlantic Airlines'),
	('9W','GMS Airlines');
