INSERT INTO bedtype VALUES ('S1','Single/twin'),
	('D1','Double'),
	('K1','King'),
	('Q1','Queen'),
	('B1','Bunk bed');
