
INSERT INTO "coupon_type_2" VALUES ('ACC','accom'),
	('ACT','activity'),
	('FLI','flight'),
	('NOT','-');
