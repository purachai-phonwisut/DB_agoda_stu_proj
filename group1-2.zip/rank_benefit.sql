
INSERT INTO "rank_benefit" VALUES (11,'Best Price Guarantee'),
	(12,'Insider deals '),
	(13,'VIP deals up to 12% off'),
	(14,'VIP deals up to 18% off'),
	(15,'VIP deals up to 25% off'),
	(16,'Free breakfast and other perks on selected properties ');
