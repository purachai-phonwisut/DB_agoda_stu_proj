

INSERT INTO "coupon_2" VALUES (1000,'no promotion','NOT'),
	(1001,'UP TO ?1,000 OFF','ACC'),
	(1002,'Enjoy up to 20% off your next trip!','ACC'),
	(1003,'AgodaVIP Program','ACC'),
	(1004,'International Deals','ACC'),
	(1005,'Continue browsing on our App!','ACC'),
	(1006,'UP TO ?1,200 OFF','ACC'),
	(1007,'Special Deal Ticket!','ACC'),
	(1008,'KTC  AGODA MASTERCARD','ACC'),
	(1009,'UP TO 15% OFF tours & attractions','FLI'),
	(1010,'Exclusive Savings','ACC'),
	(1011,'Premium Specials ','ACC'),
	(1012,'Top deals, worldwide!','ACC'),
	(1013,'Domestic Deals','ACC');
