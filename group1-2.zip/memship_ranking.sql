
INSERT INTO "memship_ranking" VALUES ('BR','Bronze',0),
	('SL','Silver',2),
	('GL','Gold',5),
	('PN','Platinum',10);
