
INSERT INTO "acttype" VALUES ('TTR','Tours&Trips'),
	('OUT','Outdoor activities'),
	('TSP','Transportation'),
	('FDR','Food & Drinks'),
	('IND','Indoor activities'),
	('EES','Events, Exhibitions & Shows'),
	('ATT','Attractions'),
	('ADC','Art, Design & Culture'),
	('HWE','Health & Wellness'),
	('TES','Travel Essentials');
