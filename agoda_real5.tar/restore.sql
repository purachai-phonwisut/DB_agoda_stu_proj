--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE agoda4;
--
-- Name: agoda4; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE agoda4 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Thai_Thailand.874';


ALTER DATABASE agoda4 OWNER TO postgres;

\connect agoda4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acc_booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acc_booking (
    accbook_id character(5) NOT NULL,
    transactime timestamp without time zone NOT NULL,
    datein date NOT NULL,
    dateout date NOT NULL,
    abbrepmt character(4) NOT NULL,
    cust_id character(5) NOT NULL,
    cp_id character(4)
);


ALTER TABLE public.acc_booking OWNER TO postgres;

--
-- Name: acc_facil; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acc_facil (
    acc_id character(6) NOT NULL,
    fac_id character(3) NOT NULL
);


ALTER TABLE public.acc_facil OWNER TO postgres;

--
-- Name: accommodation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accommodation (
    acc_id character(6) NOT NULL,
    prop_id character(3) NOT NULL,
    descr text NOT NULL,
    road text,
    prov_id character(3) NOT NULL,
    cty_id character(5) NOT NULL,
    country_id character(3) NOT NULL
);


ALTER TABLE public.accommodation OWNER TO postgres;

--
-- Name: accommodation_review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accommodation_review (
    accrev_id character(6) NOT NULL,
    decr text,
    pros text,
    cons text,
    rating_score numeric(3,1),
    accbook_id character(5)
);


ALTER TABLE public.accommodation_review OWNER TO postgres;

--
-- Name: act_booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.act_booking (
    actbook_id character(5) NOT NULL,
    opt_id character(6) NOT NULL,
    qty integer NOT NULL,
    cust_id character(5) NOT NULL,
    abbrepmt character(4) NOT NULL,
    cp_id character(4)
);


ALTER TABLE public.act_booking OWNER TO postgres;

--
-- Name: activity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity (
    act_id character(4) NOT NULL,
    title_acty text NOT NULL,
    acttype_id character(3) NOT NULL
);


ALTER TABLE public.activity OWNER TO postgres;

--
-- Name: activity_review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity_review (
    actrev_id character(6) NOT NULL,
    rating numeric(2,1) NOT NULL,
    actbook_id character(5) NOT NULL
);


ALTER TABLE public.activity_review OWNER TO postgres;

--
-- Name: acttype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acttype (
    acttype_id character(3) NOT NULL,
    descr character varying(50) NOT NULL
);


ALTER TABLE public.acttype OWNER TO postgres;

--
-- Name: airline; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.airline (
    airl_id character(2) NOT NULL,
    airl_name character varying(50) NOT NULL
);


ALTER TABLE public.airline OWNER TO postgres;

--
-- Name: airport; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.airport (
    airp_id character(3) NOT NULL,
    airp_name character varying(50) NOT NULL,
    address text NOT NULL,
    prov_id character(3) NOT NULL,
    cty_id character(5) NOT NULL,
    country_id character(3) NOT NULL
);


ALTER TABLE public.airport OWNER TO postgres;

--
-- Name: available; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.available (
    able_id character(5) NOT NULL,
    f_id character(5) NOT NULL
);


ALTER TABLE public.available OWNER TO postgres;

--
-- Name: bedtype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bedtype (
    bed_id character(2) NOT NULL,
    typebed character varying(20) NOT NULL
);


ALTER TABLE public.bedtype OWNER TO postgres;

--
-- Name: benefit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.benefit (
    benefit_id character(3) NOT NULL,
    descbene text NOT NULL
);


ALTER TABLE public.benefit OWNER TO postgres;

--
-- Name: cart_acc_booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_acc_booking (
    cust_id character(5) NOT NULL,
    room_id character(7) NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.cart_acc_booking OWNER TO postgres;

--
-- Name: cart_actbooking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_actbooking (
    cust_id character(5) NOT NULL,
    opt_id character(6) NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.cart_actbooking OWNER TO postgres;

--
-- Name: cart_flight_booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_flight_booking (
    cust_id character(5) NOT NULL,
    f_id character(5) NOT NULL,
    quantity integer NOT NULL,
    ftype_id character(3) NOT NULL,
    fclass_id character(3) NOT NULL
);


ALTER TABLE public.cart_flight_booking OWNER TO postgres;

--
-- Name: city; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.city (
    cty_id character(5) NOT NULL,
    namecity text NOT NULL
);


ALTER TABLE public.city OWNER TO postgres;

--
-- Name: country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.country (
    country_id character(3) NOT NULL,
    country_name character varying(30) NOT NULL
);


ALTER TABLE public.country OWNER TO postgres;

--
-- Name: coupon; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coupon (
    cp_id character(4) NOT NULL,
    descoupon text NOT NULL,
    cptype_id character(3) NOT NULL
);


ALTER TABLE public.coupon OWNER TO postgres;

--
-- Name: coupon_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coupon_type (
    cptype_id character(3) NOT NULL,
    cptitle character varying(10) NOT NULL
);


ALTER TABLE public.coupon_type OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    cust_id character(5) NOT NULL,
    fname character varying(50) NOT NULL,
    lname character varying(50) NOT NULL,
    dob date NOT NULL,
    tel character(12),
    email text NOT NULL,
    credcardnum character(16),
    displayname text NOT NULL,
    isguest boolean NOT NULL,
    country_id character(3) NOT NULL,
    member_rank_abbre character(2) NOT NULL
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: facility; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.facility (
    fac_id character(3) NOT NULL,
    titlefacil text NOT NULL
);


ALTER TABLE public.facility OWNER TO postgres;

--
-- Name: flight; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flight (
    f_id character(5) NOT NULL,
    f_num character(6) NOT NULL,
    airl_id character(2) NOT NULL,
    from_airport_id character(3) NOT NULL,
    to_airport_id character(3) NOT NULL,
    departure_datetime timestamp without time zone,
    arrival_datetime timestamp without time zone
);


ALTER TABLE public.flight OWNER TO postgres;

--
-- Name: flight_booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flight_booking (
    f_id character(5) NOT NULL,
    fbook_id character(5) NOT NULL,
    cust_id character(5) NOT NULL,
    ftype_id character(3) NOT NULL,
    date date NOT NULL,
    fclass_id character(3) NOT NULL,
    abbrepmt character(4) NOT NULL,
    cp_id character(4)
);


ALTER TABLE public.flight_booking OWNER TO postgres;

--
-- Name: flight_class; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flight_class (
    fclass_id character(3) NOT NULL,
    class_name character varying(50) NOT NULL
);


ALTER TABLE public.flight_class OWNER TO postgres;

--
-- Name: flight_price; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flight_price (
    flight_price_id character(5) NOT NULL,
    price numeric NOT NULL,
    effective_date date NOT NULL,
    f_id character(5) NOT NULL
);


ALTER TABLE public.flight_price OWNER TO postgres;

--
-- Name: flight_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flight_type (
    ftype_id character(3) NOT NULL,
    type_desc character varying(20) NOT NULL
);


ALTER TABLE public.flight_type OWNER TO postgres;

--
-- Name: membership_rank; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.membership_rank (
    member_rank_abbre character(2) NOT NULL,
    rank_descr character varying(20) NOT NULL,
    required_booking_quant integer NOT NULL
);


ALTER TABLE public.membership_rank OWNER TO postgres;

--
-- Name: membership_rank_benefit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.membership_rank_benefit (
    member_rank_abbre character(2) NOT NULL,
    rankbene_id character(2) NOT NULL
);


ALTER TABLE public.membership_rank_benefit OWNER TO postgres;

--
-- Name: option; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.option (
    opt_id character(6) NOT NULL,
    dateopt date NOT NULL,
    act_id character(4) NOT NULL,
    titleopt character varying(300) NOT NULL,
    prodinfo text,
    whattoexpect text,
    addinfo text
);


ALTER TABLE public.option OWNER TO postgres;

--
-- Name: option_price; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.option_price (
    optprice_id character(5) NOT NULL,
    price numeric NOT NULL,
    effective_date date NOT NULL,
    opt_id character(6) NOT NULL
);


ALTER TABLE public.option_price OWNER TO postgres;

--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    abbrepmt character(4) NOT NULL,
    typepmt text NOT NULL
);


ALTER TABLE public.payment OWNER TO postgres;

--
-- Name: property_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.property_type (
    prop_id character(3) NOT NULL,
    titleprop character varying(30) NOT NULL
);


ALTER TABLE public.property_type OWNER TO postgres;

--
-- Name: province; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.province (
    prov_id character(3) NOT NULL,
    nameprovin text NOT NULL
);


ALTER TABLE public.province OWNER TO postgres;

--
-- Name: rank_benefit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rank_benefit (
    rankbene_id character(2) NOT NULL,
    bene_descr character varying(60) NOT NULL
);


ALTER TABLE public.rank_benefit OWNER TO postgres;

--
-- Name: room; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room (
    room_id character(7) NOT NULL,
    acc_id character(6) NOT NULL,
    roomnum integer NOT NULL,
    "roomsize (sqr metres)" numeric(5,2) NOT NULL,
    nonsmoke boolean NOT NULL,
    agekidfree integer NOT NULL,
    bed_id character(2) NOT NULL
);


ALTER TABLE public.room OWNER TO postgres;

--
-- Name: room_bene; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room_bene (
    room_id character(7) NOT NULL,
    benefit_id character(3) NOT NULL
);


ALTER TABLE public.room_bene OWNER TO postgres;

--
-- Name: room_booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room_booking (
    accbook_id character(5) NOT NULL,
    room_id character(7) NOT NULL,
    qty integer NOT NULL
);


ALTER TABLE public.room_booking OWNER TO postgres;

--
-- Name: room_price; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room_price (
    room_price_id character(5) NOT NULL,
    price numeric NOT NULL,
    effective_date date NOT NULL,
    room_id character(7) NOT NULL
);


ALTER TABLE public.room_price OWNER TO postgres;

--
-- Name: seat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.seat (
    s_id character(6) NOT NULL,
    f_id character(5) NOT NULL,
    f_class character(3) NOT NULL,
    seat_qty integer NOT NULL
);


ALTER TABLE public.seat OWNER TO postgres;

--
-- Data for Name: acc_booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acc_booking (accbook_id, transactime, datein, dateout, abbrepmt, cust_id, cp_id) FROM stdin;
\.
COPY public.acc_booking (accbook_id, transactime, datein, dateout, abbrepmt, cust_id, cp_id) FROM '$$PATH$$/5067.dat';

--
-- Data for Name: acc_facil; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acc_facil (acc_id, fac_id) FROM stdin;
\.
COPY public.acc_facil (acc_id, fac_id) FROM '$$PATH$$/5068.dat';

--
-- Data for Name: accommodation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accommodation (acc_id, prop_id, descr, road, prov_id, cty_id, country_id) FROM stdin;
\.
COPY public.accommodation (acc_id, prop_id, descr, road, prov_id, cty_id, country_id) FROM '$$PATH$$/5069.dat';

--
-- Data for Name: accommodation_review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accommodation_review (accrev_id, decr, pros, cons, rating_score, accbook_id) FROM stdin;
\.
COPY public.accommodation_review (accrev_id, decr, pros, cons, rating_score, accbook_id) FROM '$$PATH$$/5070.dat';

--
-- Data for Name: act_booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.act_booking (actbook_id, opt_id, qty, cust_id, abbrepmt, cp_id) FROM stdin;
\.
COPY public.act_booking (actbook_id, opt_id, qty, cust_id, abbrepmt, cp_id) FROM '$$PATH$$/5071.dat';

--
-- Data for Name: activity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity (act_id, title_acty, acttype_id) FROM stdin;
\.
COPY public.activity (act_id, title_acty, acttype_id) FROM '$$PATH$$/5072.dat';

--
-- Data for Name: activity_review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity_review (actrev_id, rating, actbook_id) FROM stdin;
\.
COPY public.activity_review (actrev_id, rating, actbook_id) FROM '$$PATH$$/5073.dat';

--
-- Data for Name: acttype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acttype (acttype_id, descr) FROM stdin;
\.
COPY public.acttype (acttype_id, descr) FROM '$$PATH$$/5074.dat';

--
-- Data for Name: airline; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.airline (airl_id, airl_name) FROM stdin;
\.
COPY public.airline (airl_id, airl_name) FROM '$$PATH$$/5075.dat';

--
-- Data for Name: airport; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.airport (airp_id, airp_name, address, prov_id, cty_id, country_id) FROM stdin;
\.
COPY public.airport (airp_id, airp_name, address, prov_id, cty_id, country_id) FROM '$$PATH$$/5076.dat';

--
-- Data for Name: available; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.available (able_id, f_id) FROM stdin;
\.
COPY public.available (able_id, f_id) FROM '$$PATH$$/5077.dat';

--
-- Data for Name: bedtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bedtype (bed_id, typebed) FROM stdin;
\.
COPY public.bedtype (bed_id, typebed) FROM '$$PATH$$/5078.dat';

--
-- Data for Name: benefit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.benefit (benefit_id, descbene) FROM stdin;
\.
COPY public.benefit (benefit_id, descbene) FROM '$$PATH$$/5079.dat';

--
-- Data for Name: cart_acc_booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_acc_booking (cust_id, room_id, quantity) FROM stdin;
\.
COPY public.cart_acc_booking (cust_id, room_id, quantity) FROM '$$PATH$$/5080.dat';

--
-- Data for Name: cart_actbooking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_actbooking (cust_id, opt_id, quantity) FROM stdin;
\.
COPY public.cart_actbooking (cust_id, opt_id, quantity) FROM '$$PATH$$/5081.dat';

--
-- Data for Name: cart_flight_booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_flight_booking (cust_id, f_id, quantity, ftype_id, fclass_id) FROM stdin;
\.
COPY public.cart_flight_booking (cust_id, f_id, quantity, ftype_id, fclass_id) FROM '$$PATH$$/5082.dat';

--
-- Data for Name: city; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.city (cty_id, namecity) FROM stdin;
\.
COPY public.city (cty_id, namecity) FROM '$$PATH$$/5083.dat';

--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.country (country_id, country_name) FROM stdin;
\.
COPY public.country (country_id, country_name) FROM '$$PATH$$/5084.dat';

--
-- Data for Name: coupon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coupon (cp_id, descoupon, cptype_id) FROM stdin;
\.
COPY public.coupon (cp_id, descoupon, cptype_id) FROM '$$PATH$$/5085.dat';

--
-- Data for Name: coupon_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coupon_type (cptype_id, cptitle) FROM stdin;
\.
COPY public.coupon_type (cptype_id, cptitle) FROM '$$PATH$$/5086.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (cust_id, fname, lname, dob, tel, email, credcardnum, displayname, isguest, country_id, member_rank_abbre) FROM stdin;
\.
COPY public.customer (cust_id, fname, lname, dob, tel, email, credcardnum, displayname, isguest, country_id, member_rank_abbre) FROM '$$PATH$$/5087.dat';

--
-- Data for Name: facility; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.facility (fac_id, titlefacil) FROM stdin;
\.
COPY public.facility (fac_id, titlefacil) FROM '$$PATH$$/5088.dat';

--
-- Data for Name: flight; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flight (f_id, f_num, airl_id, from_airport_id, to_airport_id, departure_datetime, arrival_datetime) FROM stdin;
\.
COPY public.flight (f_id, f_num, airl_id, from_airport_id, to_airport_id, departure_datetime, arrival_datetime) FROM '$$PATH$$/5089.dat';

--
-- Data for Name: flight_booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flight_booking (f_id, fbook_id, cust_id, ftype_id, date, fclass_id, abbrepmt, cp_id) FROM stdin;
\.
COPY public.flight_booking (f_id, fbook_id, cust_id, ftype_id, date, fclass_id, abbrepmt, cp_id) FROM '$$PATH$$/5090.dat';

--
-- Data for Name: flight_class; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flight_class (fclass_id, class_name) FROM stdin;
\.
COPY public.flight_class (fclass_id, class_name) FROM '$$PATH$$/5091.dat';

--
-- Data for Name: flight_price; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flight_price (flight_price_id, price, effective_date, f_id) FROM stdin;
\.
COPY public.flight_price (flight_price_id, price, effective_date, f_id) FROM '$$PATH$$/5092.dat';

--
-- Data for Name: flight_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flight_type (ftype_id, type_desc) FROM stdin;
\.
COPY public.flight_type (ftype_id, type_desc) FROM '$$PATH$$/5093.dat';

--
-- Data for Name: membership_rank; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.membership_rank (member_rank_abbre, rank_descr, required_booking_quant) FROM stdin;
\.
COPY public.membership_rank (member_rank_abbre, rank_descr, required_booking_quant) FROM '$$PATH$$/5094.dat';

--
-- Data for Name: membership_rank_benefit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.membership_rank_benefit (member_rank_abbre, rankbene_id) FROM stdin;
\.
COPY public.membership_rank_benefit (member_rank_abbre, rankbene_id) FROM '$$PATH$$/5095.dat';

--
-- Data for Name: option; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.option (opt_id, dateopt, act_id, titleopt, prodinfo, whattoexpect, addinfo) FROM stdin;
\.
COPY public.option (opt_id, dateopt, act_id, titleopt, prodinfo, whattoexpect, addinfo) FROM '$$PATH$$/5096.dat';

--
-- Data for Name: option_price; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.option_price (optprice_id, price, effective_date, opt_id) FROM stdin;
\.
COPY public.option_price (optprice_id, price, effective_date, opt_id) FROM '$$PATH$$/5097.dat';

--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment (abbrepmt, typepmt) FROM stdin;
\.
COPY public.payment (abbrepmt, typepmt) FROM '$$PATH$$/5098.dat';

--
-- Data for Name: property_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.property_type (prop_id, titleprop) FROM stdin;
\.
COPY public.property_type (prop_id, titleprop) FROM '$$PATH$$/5099.dat';

--
-- Data for Name: province; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.province (prov_id, nameprovin) FROM stdin;
\.
COPY public.province (prov_id, nameprovin) FROM '$$PATH$$/5100.dat';

--
-- Data for Name: rank_benefit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rank_benefit (rankbene_id, bene_descr) FROM stdin;
\.
COPY public.rank_benefit (rankbene_id, bene_descr) FROM '$$PATH$$/5101.dat';

--
-- Data for Name: room; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.room (room_id, acc_id, roomnum, "roomsize (sqr metres)", nonsmoke, agekidfree, bed_id) FROM stdin;
\.
COPY public.room (room_id, acc_id, roomnum, "roomsize (sqr metres)", nonsmoke, agekidfree, bed_id) FROM '$$PATH$$/5102.dat';

--
-- Data for Name: room_bene; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.room_bene (room_id, benefit_id) FROM stdin;
\.
COPY public.room_bene (room_id, benefit_id) FROM '$$PATH$$/5103.dat';

--
-- Data for Name: room_booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.room_booking (accbook_id, room_id, qty) FROM stdin;
\.
COPY public.room_booking (accbook_id, room_id, qty) FROM '$$PATH$$/5104.dat';

--
-- Data for Name: room_price; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.room_price (room_price_id, price, effective_date, room_id) FROM stdin;
\.
COPY public.room_price (room_price_id, price, effective_date, room_id) FROM '$$PATH$$/5105.dat';

--
-- Data for Name: seat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.seat (s_id, f_id, f_class, seat_qty) FROM stdin;
\.
COPY public.seat (s_id, f_id, f_class, seat_qty) FROM '$$PATH$$/5106.dat';

--
-- Name: acc_booking acc_booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_booking
    ADD CONSTRAINT acc_booking_pkey PRIMARY KEY (accbook_id);


--
-- Name: acc_facil acc_facil_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_facil
    ADD CONSTRAINT acc_facil_pkey PRIMARY KEY (acc_id, fac_id);


--
-- Name: accommodation accommodation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accommodation
    ADD CONSTRAINT accommodation_pkey PRIMARY KEY (acc_id);


--
-- Name: accommodation_review accommodation_review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accommodation_review
    ADD CONSTRAINT accommodation_review_pkey PRIMARY KEY (accrev_id);


--
-- Name: act_booking act_booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.act_booking
    ADD CONSTRAINT act_booking_pkey PRIMARY KEY (actbook_id);


--
-- Name: activity activity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_pkey PRIMARY KEY (act_id);


--
-- Name: activity_review activity_review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_review
    ADD CONSTRAINT activity_review_pkey PRIMARY KEY (actrev_id);


--
-- Name: acttype acttype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acttype
    ADD CONSTRAINT acttype_pkey PRIMARY KEY (acttype_id);


--
-- Name: airline airline_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airline
    ADD CONSTRAINT airline_pkey PRIMARY KEY (airl_id);


--
-- Name: airport airport_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airport
    ADD CONSTRAINT airport_pkey PRIMARY KEY (airp_id);


--
-- Name: available available_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.available
    ADD CONSTRAINT available_pkey PRIMARY KEY (able_id, f_id);


--
-- Name: bedtype bedtype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bedtype
    ADD CONSTRAINT bedtype_pkey PRIMARY KEY (bed_id);


--
-- Name: benefit benefit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.benefit
    ADD CONSTRAINT benefit_pkey PRIMARY KEY (benefit_id);


--
-- Name: cart_acc_booking cart_acc_booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_acc_booking
    ADD CONSTRAINT cart_acc_booking_pkey PRIMARY KEY (cust_id, room_id);


--
-- Name: cart_actbooking cart_actbooking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_actbooking
    ADD CONSTRAINT cart_actbooking_pkey PRIMARY KEY (cust_id, opt_id);


--
-- Name: cart_flight_booking cart_flight_booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_flight_booking
    ADD CONSTRAINT cart_flight_booking_pkey PRIMARY KEY (cust_id, f_id);


--
-- Name: city city_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city
    ADD CONSTRAINT city_pkey PRIMARY KEY (cty_id);


--
-- Name: country country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT country_pkey PRIMARY KEY (country_id);


--
-- Name: coupon coupon_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupon
    ADD CONSTRAINT coupon_pkey PRIMARY KEY (cp_id);


--
-- Name: coupon_type coupon_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupon_type
    ADD CONSTRAINT coupon_type_pkey PRIMARY KEY (cptype_id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (cust_id);


--
-- Name: facility facility_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.facility
    ADD CONSTRAINT facility_pkey PRIMARY KEY (fac_id);


--
-- Name: flight_booking flight_booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_booking
    ADD CONSTRAINT flight_booking_pkey PRIMARY KEY (fbook_id);


--
-- Name: flight_class flight_class_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_class
    ADD CONSTRAINT flight_class_pkey PRIMARY KEY (fclass_id);


--
-- Name: flight flight_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight
    ADD CONSTRAINT flight_pkey PRIMARY KEY (f_id);


--
-- Name: flight_price flight_price_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_price
    ADD CONSTRAINT flight_price_pkey PRIMARY KEY (flight_price_id);


--
-- Name: flight_type flight_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_type
    ADD CONSTRAINT flight_type_pkey PRIMARY KEY (ftype_id);


--
-- Name: membership_rank_benefit membership_rank_benefit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membership_rank_benefit
    ADD CONSTRAINT membership_rank_benefit_pkey PRIMARY KEY (member_rank_abbre, rankbene_id);


--
-- Name: membership_rank membership_rank_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membership_rank
    ADD CONSTRAINT membership_rank_pkey PRIMARY KEY (member_rank_abbre);


--
-- Name: option option_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option
    ADD CONSTRAINT option_pkey PRIMARY KEY (opt_id);


--
-- Name: option_price option_price_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option_price
    ADD CONSTRAINT option_price_pkey PRIMARY KEY (optprice_id);


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (abbrepmt);


--
-- Name: property_type property_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.property_type
    ADD CONSTRAINT property_type_pkey PRIMARY KEY (prop_id);


--
-- Name: province province_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.province
    ADD CONSTRAINT province_pkey PRIMARY KEY (prov_id);


--
-- Name: rank_benefit rank_benefit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rank_benefit
    ADD CONSTRAINT rank_benefit_pkey PRIMARY KEY (rankbene_id);


--
-- Name: room_bene room_bene_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_bene
    ADD CONSTRAINT room_bene_pkey PRIMARY KEY (room_id, benefit_id);


--
-- Name: room_booking room_booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_booking
    ADD CONSTRAINT room_booking_pkey PRIMARY KEY (accbook_id, room_id);


--
-- Name: room room_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_pkey PRIMARY KEY (room_id);


--
-- Name: room_price room_price_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_price
    ADD CONSTRAINT room_price_pkey PRIMARY KEY (room_price_id);


--
-- Name: seat seat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seat
    ADD CONSTRAINT seat_pkey PRIMARY KEY (s_id);


--
-- Name: acc_booking acc_booking_abbrepmt_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_booking
    ADD CONSTRAINT acc_booking_abbrepmt_fkey FOREIGN KEY (abbrepmt) REFERENCES public.payment(abbrepmt) NOT VALID;


--
-- Name: acc_booking acc_booking_cp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_booking
    ADD CONSTRAINT acc_booking_cp_id_fkey FOREIGN KEY (cp_id) REFERENCES public.coupon(cp_id) NOT VALID;


--
-- Name: acc_booking acc_booking_cust_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_booking
    ADD CONSTRAINT acc_booking_cust_id_fkey FOREIGN KEY (cust_id) REFERENCES public.customer(cust_id) NOT VALID;


--
-- Name: acc_facil acc_facil_acc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_facil
    ADD CONSTRAINT acc_facil_acc_id_fkey FOREIGN KEY (acc_id) REFERENCES public.accommodation(acc_id) NOT VALID;


--
-- Name: acc_facil acc_facil_fac_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_facil
    ADD CONSTRAINT acc_facil_fac_id_fkey FOREIGN KEY (fac_id) REFERENCES public.facility(fac_id) NOT VALID;


--
-- Name: accommodation accommodation_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accommodation
    ADD CONSTRAINT accommodation_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.country(country_id) NOT VALID;


--
-- Name: accommodation accommodation_cty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accommodation
    ADD CONSTRAINT accommodation_cty_id_fkey FOREIGN KEY (cty_id) REFERENCES public.city(cty_id) NOT VALID;


--
-- Name: accommodation accommodation_prop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accommodation
    ADD CONSTRAINT accommodation_prop_id_fkey FOREIGN KEY (prop_id) REFERENCES public.property_type(prop_id) NOT VALID;


--
-- Name: accommodation accommodation_prov_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accommodation
    ADD CONSTRAINT accommodation_prov_id_fkey FOREIGN KEY (prov_id) REFERENCES public.province(prov_id) NOT VALID;


--
-- Name: accommodation_review accommodation_review_accbook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accommodation_review
    ADD CONSTRAINT accommodation_review_accbook_id_fkey FOREIGN KEY (accbook_id) REFERENCES public.acc_booking(accbook_id) NOT VALID;


--
-- Name: act_booking act_booking_abbrepmt_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.act_booking
    ADD CONSTRAINT act_booking_abbrepmt_fkey FOREIGN KEY (abbrepmt) REFERENCES public.payment(abbrepmt) NOT VALID;


--
-- Name: act_booking act_booking_cp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.act_booking
    ADD CONSTRAINT act_booking_cp_id_fkey FOREIGN KEY (cp_id) REFERENCES public.coupon(cp_id) NOT VALID;


--
-- Name: act_booking act_booking_cust_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.act_booking
    ADD CONSTRAINT act_booking_cust_id_fkey FOREIGN KEY (cust_id) REFERENCES public.customer(cust_id) NOT VALID;


--
-- Name: act_booking act_booking_opt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.act_booking
    ADD CONSTRAINT act_booking_opt_id_fkey FOREIGN KEY (opt_id) REFERENCES public.option(opt_id) NOT VALID;


--
-- Name: activity activity_acttype_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_acttype_id_fkey FOREIGN KEY (acttype_id) REFERENCES public.acttype(acttype_id) NOT VALID;


--
-- Name: activity_review activity_review_actbook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_review
    ADD CONSTRAINT activity_review_actbook_id_fkey FOREIGN KEY (actbook_id) REFERENCES public.act_booking(actbook_id) NOT VALID;


--
-- Name: airport airport_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airport
    ADD CONSTRAINT airport_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.country(country_id) NOT VALID;


--
-- Name: airport airport_cty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airport
    ADD CONSTRAINT airport_cty_id_fkey FOREIGN KEY (cty_id) REFERENCES public.city(cty_id) NOT VALID;


--
-- Name: airport airport_prov_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airport
    ADD CONSTRAINT airport_prov_id_fkey FOREIGN KEY (prov_id) REFERENCES public.province(prov_id) NOT VALID;


--
-- Name: available available_able_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.available
    ADD CONSTRAINT available_able_id_fkey FOREIGN KEY (able_id) REFERENCES public.flight(f_id) NOT VALID;


--
-- Name: available available_f_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.available
    ADD CONSTRAINT available_f_id_fkey FOREIGN KEY (f_id) REFERENCES public.flight(f_id) NOT VALID;


--
-- Name: cart_acc_booking cart_acc_booking_cust_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_acc_booking
    ADD CONSTRAINT cart_acc_booking_cust_id_fkey FOREIGN KEY (cust_id) REFERENCES public.customer(cust_id) NOT VALID;


--
-- Name: cart_acc_booking cart_acc_booking_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_acc_booking
    ADD CONSTRAINT cart_acc_booking_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.room(room_id) NOT VALID;


--
-- Name: cart_actbooking cart_actbooking_cust_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_actbooking
    ADD CONSTRAINT cart_actbooking_cust_id_fkey FOREIGN KEY (cust_id) REFERENCES public.customer(cust_id) NOT VALID;


--
-- Name: cart_actbooking cart_actbooking_opt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_actbooking
    ADD CONSTRAINT cart_actbooking_opt_id_fkey FOREIGN KEY (opt_id) REFERENCES public.option(opt_id) NOT VALID;


--
-- Name: cart_flight_booking cart_flight_booking_cust_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_flight_booking
    ADD CONSTRAINT cart_flight_booking_cust_id_fkey FOREIGN KEY (cust_id) REFERENCES public.customer(cust_id) NOT VALID;


--
-- Name: cart_flight_booking cart_flight_booking_f_id.fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_flight_booking
    ADD CONSTRAINT "cart_flight_booking_f_id.fkey" FOREIGN KEY (f_id) REFERENCES public.flight(f_id) NOT VALID;


--
-- Name: cart_flight_booking cart_flight_booking_fclass_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_flight_booking
    ADD CONSTRAINT cart_flight_booking_fclass_id_fkey FOREIGN KEY (fclass_id) REFERENCES public.flight_class(fclass_id) NOT VALID;


--
-- Name: cart_flight_booking cart_flight_booking_ftype_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_flight_booking
    ADD CONSTRAINT cart_flight_booking_ftype_id_fkey FOREIGN KEY (ftype_id) REFERENCES public.flight_type(ftype_id) NOT VALID;


--
-- Name: coupon coupon_cptype_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupon
    ADD CONSTRAINT coupon_cptype_id_fkey FOREIGN KEY (cptype_id) REFERENCES public.coupon_type(cptype_id) NOT VALID;


--
-- Name: customer customer_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.country(country_id) NOT VALID;


--
-- Name: customer customer_member_rank_abbre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_member_rank_abbre_fkey FOREIGN KEY (member_rank_abbre) REFERENCES public.membership_rank(member_rank_abbre) NOT VALID;


--
-- Name: flight flight_airl_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight
    ADD CONSTRAINT flight_airl_id_fkey FOREIGN KEY (airl_id) REFERENCES public.airline(airl_id) NOT VALID;


--
-- Name: flight_booking flight_booking_abbrepmt_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_booking
    ADD CONSTRAINT flight_booking_abbrepmt_fkey FOREIGN KEY (abbrepmt) REFERENCES public.payment(abbrepmt) NOT VALID;


--
-- Name: flight_booking flight_booking_cp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_booking
    ADD CONSTRAINT flight_booking_cp_id_fkey FOREIGN KEY (cp_id) REFERENCES public.coupon(cp_id) NOT VALID;


--
-- Name: flight_booking flight_booking_cust_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_booking
    ADD CONSTRAINT flight_booking_cust_id_fkey FOREIGN KEY (cust_id) REFERENCES public.customer(cust_id) NOT VALID;


--
-- Name: flight_booking flight_booking_f_id.fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_booking
    ADD CONSTRAINT "flight_booking_f_id.fkey" FOREIGN KEY (f_id) REFERENCES public.flight(f_id) NOT VALID;


--
-- Name: flight_booking flight_booking_fclass_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_booking
    ADD CONSTRAINT flight_booking_fclass_id_fkey FOREIGN KEY (fclass_id) REFERENCES public.flight_class(fclass_id) NOT VALID;


--
-- Name: flight_booking flight_booking_ftype_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_booking
    ADD CONSTRAINT flight_booking_ftype_id_fkey FOREIGN KEY (ftype_id) REFERENCES public.flight_type(ftype_id) NOT VALID;


--
-- Name: flight flight_from_airport_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight
    ADD CONSTRAINT flight_from_airport_id_fkey FOREIGN KEY (from_airport_id) REFERENCES public.airport(airp_id) NOT VALID;


--
-- Name: flight_price flight_price_f_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_price
    ADD CONSTRAINT flight_price_f_id_fkey FOREIGN KEY (f_id) REFERENCES public.flight(f_id) NOT VALID;


--
-- Name: flight flight_to_airport_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight
    ADD CONSTRAINT flight_to_airport_id_fkey FOREIGN KEY (to_airport_id) REFERENCES public.airport(airp_id) NOT VALID;


--
-- Name: membership_rank_benefit membership_rank_benefit_member_rank_abbre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membership_rank_benefit
    ADD CONSTRAINT membership_rank_benefit_member_rank_abbre_fkey FOREIGN KEY (member_rank_abbre) REFERENCES public.membership_rank(member_rank_abbre) NOT VALID;


--
-- Name: membership_rank_benefit membership_rank_benefit_rankbene_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membership_rank_benefit
    ADD CONSTRAINT membership_rank_benefit_rankbene_id_fkey FOREIGN KEY (rankbene_id) REFERENCES public.rank_benefit(rankbene_id) NOT VALID;


--
-- Name: option option_act_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option
    ADD CONSTRAINT option_act_id_fkey FOREIGN KEY (act_id) REFERENCES public.activity(act_id) NOT VALID;


--
-- Name: option_price option_price_opt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option_price
    ADD CONSTRAINT option_price_opt_id_fkey FOREIGN KEY (opt_id) REFERENCES public.option(opt_id) NOT VALID;


--
-- Name: room room_acc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_acc_id_fkey FOREIGN KEY (acc_id) REFERENCES public.accommodation(acc_id) NOT VALID;


--
-- Name: room room_bed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_bed_id_fkey FOREIGN KEY (bed_id) REFERENCES public.bedtype(bed_id) NOT VALID;


--
-- Name: room_bene room_bene_benefit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_bene
    ADD CONSTRAINT room_bene_benefit_id_fkey FOREIGN KEY (benefit_id) REFERENCES public.benefit(benefit_id) NOT VALID;


--
-- Name: room_bene room_bene_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_bene
    ADD CONSTRAINT room_bene_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.room(room_id) NOT VALID;


--
-- Name: room_booking room_booking_accbook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_booking
    ADD CONSTRAINT room_booking_accbook_id_fkey FOREIGN KEY (accbook_id) REFERENCES public.acc_booking(accbook_id) NOT VALID;


--
-- Name: room_booking room_booking_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_booking
    ADD CONSTRAINT room_booking_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.room(room_id) NOT VALID;


--
-- Name: room_price room_price_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_price
    ADD CONSTRAINT room_price_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.room(room_id) NOT VALID;


--
-- Name: seat seat_f_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seat
    ADD CONSTRAINT seat_f_class_fkey FOREIGN KEY (f_class) REFERENCES public.flight_class(fclass_id) NOT VALID;


--
-- Name: seat seat_f_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seat
    ADD CONSTRAINT seat_f_id_fkey FOREIGN KEY (f_id) REFERENCES public.flight(f_id) NOT VALID;


--
-- PostgreSQL database dump complete
--

